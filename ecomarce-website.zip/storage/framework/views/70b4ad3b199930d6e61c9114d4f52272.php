<div class="col-xl-3 col-lg-4 order-lg-1">
    <div class="sidebar-toggle position-left"><i class="icon-filter"></i></div>
    <aside class="sidebar sidebar-offcanvas position-left"><span class="sidebar-close"><i
                class="icon-x"></i></span>
        <!-- Widget Search-->
        <section class="widget">
            <form action="<?php echo e(route('user.search')); ?>" class="input-group form-group"
                method="get"><span class="input-group-btn">
                    <button type="submit"><i class="icon-search"></i></button></span>
                <input class="form-control" name="search" type="text" placeholder="Search blog">
            </form>
        </section>
        <!-- Widget Categories-->
        <section class="widget widget-categories card rounded p-4 mt-n3">
            <h3 class="widget-title">Blog Categories</h3>
            <ul>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a
                    href="<?php echo e(route('user.blog.category', ['id'=>$category->id])); ?>"><?php echo e($category->name); ?></a>
            </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
                

            </ul>
        </section>
        <!-- Widget Featured Posts-->
        <section class="widget widget-featured-posts card rounded p-4">
            <h3 class="widget-title">Most Recent Added Posts</h3>
            <?php $__currentLoopData = $recent_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="entry">
                <div class="entry-thumb"><a
                        href="<?php echo e(route('user.blog_details', ['id'=>$rblog->id])); ?>"><img
                            src="<?php echo e(asset('storage')); ?>/<?php echo e($rblog->image); ?>"
                            alt="Post"></a></div>
                <div class="entry-content">
                    <h4 class="entry-title"><a
                            href="<?php echo e(route('user.blog_details', ['id'=>$rblog->id])); ?>">
                            <?php echo e($rblog->title); ?>


                        </a></h4><span class="entry-meta">by Admin</span>
                </div>
            </div>
        </section>
    </aside>
</div><?php /**PATH D:\ecomarce-website\resources\views/includes/blog-sidebar.blade.php ENDPATH**/ ?>