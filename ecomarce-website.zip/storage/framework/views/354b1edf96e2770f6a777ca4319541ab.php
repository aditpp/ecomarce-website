<?php $__env->startSection('title'); ?>
    Update Slider
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="page-inner">

            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="d-sm-flex align-items-center justify-content-between">
                            <h3 class=" mb-0 bc-title"><b>Update Slider</b> </h3>
                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.slider.index')); ?>"><i
                                    class="fas fa-chevron-left"></i>
                                Back</a>
                        </div>
                    </div>
                </div>

                <!-- Form -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="card o-hidden border-0 shadow-lg">
                            <div class="card-body ">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="tab-content" id="pills-tabContent">
                                            <div class="tab-pane fade show active" aria-labelledby="pills-home-tab">
                                                <form action="<?php echo e(route('admin.slider.update',['id'=>$slider->id])); ?>"
                                                    method="POST" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label for="title">Title *</label>
                                                        <input type="text"  name="title" class="form-control"
                                                            id="title" placeholder="Enter Title" value="<?php echo e($slider->title); ?>">
                                                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="slider-link">Link *</label>
                                                        <input type="text" name="url" val class="form-control"
                                                            id="slider-link" placeholder="Enter Link" value="<?php echo e($slider->url); ?>">
                                                            <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="details">Details *</label>
                                                        <textarea name="details" id="details" class="form-control" rows="5" placeholder="Enter Details"><?php echo e($slider->details); ?></textarea>
                                                        <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    <div class="form-group">
                                                        <label id="slider_text" for="name">Set Slider Image *</label>
                                                        <br>
                                                        <img class="admin-img"
                                                            src="<?php echo e(asset('storage')); ?>/<?php echo e($slider->image); ?>"
                                                            alt="No Image Found">
                                                        <br>
                                                        <span id="chenge_label2" class="mt-1">Image Size Should Be 968 x
                                                            530 </span>
                                                    </div>

                                                    <div class="form-group position-relative ">
                                                        <label class="file">
                                                            <input type="file" accept="image/*" class="upload-photo"
                                                                name="image" id="file"
                                                                aria-label="File browser example">
                                                            <span class="file-custom text-left">Upload Image...</span>
                                                        </label>
                                                    </div>
                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                    <div class="form-group">
                                                        <button type="submit" class="btn btn-secondary ">Submit</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecomarce-website\resources\views/admin/slider/update.blade.php ENDPATH**/ ?>