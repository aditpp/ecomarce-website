<?php $__env->startSection('title'); ?>
    Blog
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumbs">
                        <li><a href="/">Home</a> </li>
                        <li class="separator"></li>
                        <li>Blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container padding-bottom-3x mb-1 blog-page">
        <div class="row ">
            <!-- Content-->
            <div class="col-xl-9 col-lg-8 order-lg-2">
                <div class="row">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('user.blog_details', ['id'=>$blog->id])); ?>"
                            class="blog-post">
                            <div class="post-thumb">
                                <img class="lazy" alt="Blog Post"
                                    src="<?php echo e(asset('storage')); ?>/<?php echo e($blog->image); ?>"
                                    style="">
                            </div>
                            <div class="post-body">

                                <h3 class="post-title"> <?php echo e($blog->title); ?>

                                </h3>
                                <ul class="post-meta">

                                    <li><i class="icon-user"></i>Admin</li>
                                    <li><i class="icon-clock"></i><?php echo e(\Carbon\Carbon::now()->format('Y, M d',strtotime($blog->created_at))); ?></li>
                                </ul>
                                <p><?php echo substr($blog->description, 0, 50); ?>

                                </p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
            </div>
            <!-- Sidebar          -->
          <?php echo $__env->make('includes.blog-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecomarce-website\resources\views/user/blog.blade.php ENDPATH**/ ?>