<?php $__env->startSection('title'); ?>
    Brand
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="container">
            <div class="column">
                <ul class="breadcrumbs">
                    <li><a href="/">Home</a> </li>
                    <li class="separator"></li>
                    <li>Billing address</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container padding-bottom-3x mb-1 checkut-page">
        <div class="row">
            <!-- Billing Adress-->
            <div class="col-xl-9 col-lg-8">
                <?php echo $__env->make('includes.steps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card">
                    <div class="card-body">
                        <h6>Billing Address</h6>
                        <form id="checkoutBilling"
                            action="<?php echo e(route('user.billing_address')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-fn">First Name</label>
                                        <input class="form-control" disabled name="bill_first_name" type="text" required=""
                                            id="checkout-fn" value="<?php echo e(Auth::user()->first_name); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-ln">Last Name</label>
                                        <input class="form-control" disabled name="bill_last_name" type="text" required=""
                                            id="checkout-ln" value="<?php echo e(Auth::user()->last_name); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout_email_billing">E-mail Address</label>
                                        <input class="form-control" disabled name="bill_email" type="email" required=""
                                            id="checkout_email_billing" value="<?php echo e(Auth::user()->email); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-phone">Phone Number</label>
                                        <input class="form-control" name="phone" type="text" id="checkout-phone"
                                            required="" value="<?php echo e($billing_address->phone); ?>">

                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-phone">Address1</label>
                                        <input class="form-control" name="address1" type="text" id="checkout-phone"
                                            required="" value="<?php echo e($billing_address->address1); ?>">
                                            <?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-phone">Address2</label>
                                        <input class="form-control" name="address2" type="text" id="checkout-phone"
                                            required="" value="<?php echo e($billing_address->address2); ?>">
                                            <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-phone">Zip Code</label>
                                        <input class="form-control" name="zip_code" type="text" id="checkout-phone"
                                            required="" value="<?php echo e($billing_address->zip_code); ?>">
                                            <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-phone">Company</label>
                                        <input class="form-control" name="company" type="text" id="checkout-phone"
                                            required="" value="<?php echo e($billing_address->company); ?>">

                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="checkout-phone">City</label>
                                        <input class="form-control" name="city" type="text" id="checkout-phone"
                                            required="" value="<?php echo e($billing_address->city); ?>">
                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" id="trams__condition">
                                    <label class="custom-control-label" for="trams__condition">This site is protected by
                                        reCAPTCHA and the <a href="http://localhost/my/omnimart3/privacy-policy"
                                            target="_blank">Privacy Policy</a> and <a
                                            href="http://localhost/my/omnimart3/terms-and-service" target="_blank">Terms of
                                            Service</a> apply.</label>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between paddin-top-1x mt-4">
                                <a class="btn btn-primary btn-sm"
                                    href="https://geniusdevs.com/codecanyon/omnimart40/cart"><span class="hidden-xs-down"><i
                                            class="icon-arrow-left"></i>Back To Cart</span></a>
                                <button disabled="" id="continue__button" class="btn btn-primary  btn-sm"
                                    type="button"><span class="hidden-xs-down">Continue</span><i
                                        class="icon-arrow-right"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Sidebar          -->
            <?php echo $__env->make('includes.order-summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecomarce-website\resources\views/user/checkout.blade.php ENDPATH**/ ?>