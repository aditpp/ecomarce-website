<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $__env->yieldContent('title'); ?> | Pakistan online ( Online bazaar )</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" type="image/x-icon"
        href="https://geniusdevs.com/codecanyon/omnimart40/assets/images/1629651232pre.png" />

    <script src="https://geniusdevs.com/codecanyon/omnimart40/assets/back/js/plugin/webfont/webfont.min.js"></script>
    <script id="setFont" data-src="https://geniusdevs.com/codecanyon/omnimart40/assets/back/css/fonts.css"
        src="https://geniusdevs.com/codecanyon/omnimart40/assets/back/js/plugin/webfont/setfont.js"></script>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/azzara.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/tagify.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/editor.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/bootstrap-iconpicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/magnific-popup.css')); ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/back/css/custom.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div class="wrapper">

        <?php echo $__env->make('includes.admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Sidebar -->
        <?php echo $__env->make('includes.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- End Sidebar -->

        <div class="main-panel">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>

    <script>
        var mainbs = {
            "is_announcement": "1",
            "announcement_delay": "1.00",
            "overlay": null
        };
    </script>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/back/js/jquery.3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/js/bootstrap.min.js')); ?>"></script>

    <!-- jQuery UI -->
    <script src="<?php echo e(asset('assets/back/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/js/jquery.ui.touch-punch.min.js')); ?>"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo e(asset('assets/back/js/jquery.scrollbar.min.js')); ?>"></script>

    <!-- Moment JS -->
    <script src="<?php echo e(asset('assets/back/js/moment.min.js')); ?>"></script>

    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/back/js/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Bootstrap Notify -->
    <script src="<?php echo e(asset('assets/back/js/bootstrap-notify.min.js')); ?>"></script>


    <!-- Bootstrap Notify -->
    <script src="<?php echo e(asset('assets/back/js/bootstrap-notify.min.js')); ?>"></script>

    <!-- Chartjs -->
    <script src="<?php echo e(asset('assets/back/js/chart.min.js')); ?>"></script>

    <!-- Editor -->
    <script src="<?php echo e(asset('assets/back/js/editor.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/back/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Tagify -->
    <script src="<?php echo e(asset('assets/back/js/tagify.js')); ?>"></script>

    <!-- JS Color -->
    <script src="<?php echo e(asset('assets/back/js/jscolor.js')); ?>"></script>

    <!-- Magnific Popup -->
    <script src="<?php echo e(asset('assets/back/js/jquery.magnific-popup.min.js')); ?>"></script>

    <!-- Sortable -->
    <script src="<?php echo e(asset('assets/back/js/sortable.js')); ?>"></script>

    <!-- Icon Picker -->
    <script src="<?php echo e(asset('assets/back/js/bootstrap-iconpicker.bundle.min.js')); ?>"></script>

    <!-- Azzara JS -->
    <script src="<?php echo e(asset('assets/back/js/ready.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/back/js/custom.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    </script>

    <?php if(session()->has('success')): ?>
        <script>
            toastr["success"]("<?php echo e(session('success')); ?>")
        </script>
    <?php elseif(session()->has('error')): ?>
        <script>
            toastr["error"]("<?php echo e(session('error')); ?>")
        </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('footer'); ?>
</body>

</html>
<?php /**PATH D:\ecomarce-website\resources\views/layouts/admin.blade.php ENDPATH**/ ?>