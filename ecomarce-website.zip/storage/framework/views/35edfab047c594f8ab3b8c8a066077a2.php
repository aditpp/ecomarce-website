<?php $__env->startSection('title'); ?>
    Shop
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumbs">
                        <li><a href="/">Home</a> </li>
                        <li class="separator"></li>
                        <li>Shop</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Content-->
    <div class="container padding-bottom-3x mb-1">
     
        <div class="row g-3">

            <div class="col-lg-9 order-lg-2" id="list_view_ajax">
                <!-- Shop Toolbar-->
                <div class="row g-3">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="product-card">
                                <div class="product-thumb">
                                    <img class="lazy" data-src="<?php echo e(asset('storage')); ?>/<?php echo e($product->featured_image); ?>"
                                        alt="Product">
                                    <div class="product-button-group">
                                        <?php if(Auth::user() && Auth::user()->id): ?>
                                            <a class="product-button wishlist_store"
                                                href="<?php echo e(route('user.add_to_wishlist', ['id' => $product->id])); ?>"
                                                title="Wishlist"><i class="icon-heart"></i></a>
                                        <?php else: ?>
                                            <a class="product-button wishlist_store" href="<?php echo e(route('user.register')); ?>"
                                                title="Wishlist"><i class="icon-heart"></i></a>
                                        <?php endif; ?>

                                        <?php if(Auth::user() && Auth::user()->id): ?>
                                            <a data-target="" class="product-button product_compare"
                                                href="<?php echo e(route('user.add_to_compare', ['id' => $product->id])); ?>"
                                                title="Compare"><i class="icon-repeat"></i></a>
                                        <?php else: ?>
                                            <a data-target="" class="product-button product_compare"
                                                href="<?php echo e(route('user.register')); ?>" title="Compare"><i
                                                    class="icon-repeat"></i></a>
                                        <?php endif; ?>

                                        <?php if(Auth::user() && Auth::user()->id): ?>
                                            <a class="product-button add_to_single_cart" data-target="563"
                                                href="<?php echo e(route('user.add_to_cart', ['id' => $product->id])); ?>"
                                                title="To Cart"><i class="icon-shopping-cart"></i>
                                            </a>
                                        <?php else: ?>
                                            <a class="product-button add_to_single_cart" data-target="563"
                                                href="<?php echo e(route('user.register')); ?>" title="To Cart"><i
                                                    class="icon-shopping-cart"></i>
                                            </a>
                                        <?php endif; ?>



                                    </div>
                                </div>
                                <div class="product-card-body">
                                    <div class="product-category"><a href=""><?php echo e($product->categories->name); ?></a>
                                    </div>
                                    <h3 class="product-title"><a
                                            href="<?php echo e(route('user.product_details', ['slug' => $product->slug])); ?>">
                                            <?php echo e(\Illuminate\Support\Str::substr($product->name, 0, 50)); ?>

                                        </a></h3>
                               
                                    <h4 class="product-price">
                                        <del>$<?php echo e($product->previous_price); ?></del>

                                        $<?php echo e($product->current_price); ?>

                                    </h4>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination-->
                <div class="row mt-15" id="item_pagination">
                    <div class="col-lg-12 text-center">
                    </div>
                </div>
            </div>

            <!-- Sidebar          -->
            <div class="col-lg-3 order-lg-1">
                <div class="sidebar-toggle position-left"><i class="icon-filter"></i></div>
                <aside class="sidebar sidebar-offcanvas position-left"><span class="sidebar-close"><i
                            class="icon-x"></i></span>
                    <!-- Widget Categories-->
                    <section class="widget widget-categories card rounded p-4">
                        <h3 class="widget-title">Shop Categories</h3>
                        <ul id="category_list" class="category-scroll">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="has-children">
                                <a class="category_search" href="#" data-href="Women-Clothing"><?php echo e($category->name); ?></a>

                                <ul id="subcategory_list">
                                    <?php $__currentLoopData = $category->sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="">
                                        <a class="subcategory" href="<?php echo e(route('user.shop.sub.category', ['id'=>$sub_category->id,'cat_id'=>$category->id])); ?>" data-href="Womens-Underwear"><?php echo e($sub_category->name); ?></a>
                                        <ul id="childcategory_list">
                                        <?php $__currentLoopData = $sub_category->child_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="">
                                                <a class="childcategory" href="<?php echo e(route('user.shop.child.category', ['id'=>$child_category->id,'sub_id'=>$sub_category->id,'cat_id'=>$category->id])); ?>" data-href="Pajama-Sets"><?php echo e($child_category->name); ?></a>

                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </ul>
                    </section>

                    <!-- Widget Brand Filter-->
                    
                </aside>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecomarce-website\resources\views/user/shop.blade.php ENDPATH**/ ?>