<?php $__env->startSection('title'); ?>
    Faq
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumbs">
                        <li><a href="/">Home</a> </li>
                        <li class="separator"></li>
                        <li>Faq</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container pt-3 pb-3">
        <div class="row pb-4">
            <?php $__currentLoopData = $faq_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo e(route('user.faqs', ['slug' => $faq->slug])); ?>" class="card mb-4 faq-box">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($faq->name); ?></h6>
                        <p class="card-text"><?php echo e($faq->text); ?></p>
                        <span class="text-sm text-muted link">View Details <i class="icon-chevron-right"></i></span>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecomarce-website\resources\views/user/faq-category.blade.php ENDPATH**/ ?>