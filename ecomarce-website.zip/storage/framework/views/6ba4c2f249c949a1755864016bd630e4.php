<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="slider-area-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <!-- Main Slider-->
                    <div class="hero-slider">
                        <div class="hero-slider-main owl-carousel dots-inside">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item" style="background: url('<?php echo e(asset('storage')); ?>/<?php echo e($slider->image); ?>')">
                                    <div class="item-inner">
                                        <div class="from-bottom">
                                            <div class="title text-body"><?php echo e($slider->title); ?></div>
                                            <div class="subtitle text-body"><?php echo e($slider->details); ?></div>
                                        </div>
                                        <a class="btn btn-primary scale-up delay-1" href="<?php echo e($slider->url); ?>"> <span>Buy
                                                Now</span>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4 d-none d-lg-block">
                    <a href="#" class="sright-image">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($home_page_value->image1); ?>" alt="">
                        <div class="inner-content">

                            <p><?php echo e($home_page_value->title1); ?></p>

                            <h4><?php echo e($home_page_value->sub_title1); ?></h4>
                        </div>
                    </a>
                    <a href="#" class="sright-image">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($home_page_value->image2); ?>" alt="">
                        <div class="inner-content">

                            <p><?php echo e($home_page_value->title2); ?></p>

                            <h4><?php echo e($home_page_value->sub_title2); ?></h4>
                        </div>
                    </a>
                </div>

            </div>
        </div>
    </div>


    <section class="service-section">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-6 text-center mb-30">
                        <div class="single-service single-service2">
                            <img src="<?php echo e(asset('storage')); ?>/<?php echo e($service->image); ?>" alt="Shipping">
                            <div class="content ml-3">
                                <h6 class="mb-2 "><?php echo e($service->title); ?></h6>
                                <p class="text-sm text-muted mb-0"><?php echo e($service->sub_title); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>


    <div class="deal-of-day-section mt-20">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="h3"><?php echo e($categories1->name); ?></h2>
                        <div class="right-area">
                            <a class="right_link" href="">View
                                All <i class="icon-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-lg-12">
                    <div class="popular-category-slider owl-carousel">
                        <?php $__currentLoopData = $categories1->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item">
                                <div class="product-card">
                                    <div class="product-thumb">
                                        <img class="lazy"
                                            data-src="<?php echo e(asset('storage')); ?>/<?php echo e($product->featured_image); ?>"
                                            alt="Product">
                                        <div class="product-button-group">
                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.add_to_wishlist', ['id' => $product->id])); ?>"
                                                    title="Wishlist"><i class="icon-heart"></i></a>
                                            <?php else: ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.register')); ?>" title="Wishlist"><i
                                                        class="icon-heart"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.add_to_compare', ['id' => $product->id])); ?>"
                                                    title="Compare"><i class="icon-repeat"></i></a>
                                            <?php else: ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.register')); ?>" title="Compare"><i
                                                        class="icon-repeat"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.add_to_cart', ['id' => $product->id])); ?>"
                                                    title="To Cart"><i class="icon-shopping-cart"></i>
                                                </a>
                                            <?php else: ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.register')); ?>" title="To Cart"><i
                                                        class="icon-shopping-cart"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="product-card-body">
                                        <div class="product-category"><a href="/shop/category/<?php echo e($categories1->slug); ?>"><?php echo e($categories1->name); ?></a></div>
                                        <h3 class="product-title"><a
                                                href="<?php echo e(route('user.product_details', ['slug' => $product->slug])); ?>">
                                                <?php echo e(\Illuminate\Support\Str::substr($product->name, 0, 50)); ?>

                                            </a></h3>

                                        <h4 class="product-price">
                                            <del>$<?php echo e($product->previous_price); ?></del>

                                            $<?php echo e($product->current_price); ?>

                                        </h4>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="bannner-section mt-60">
        <div class="container ">
            <div class="row gx-3">
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($first_three_column_value->image1); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($first_three_column_value->title1); ?></p>
                            <h4><?php echo e($first_three_column_value->sub_title1); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($first_three_column_value->image2); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($first_three_column_value->title2); ?></p>
                            <h4><?php echo e($first_three_column_value->sub_title2); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($first_three_column_value->image3); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($first_three_column_value->title3); ?></p>
                            <h4><?php echo e($first_three_column_value->sub_title3); ?></h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="deal-of-day-section mt-20">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="h3"><?php echo e($categories2->name); ?></h2>
                        <div class="right-area">
                            <a class="right_link" href="">View
                                All <i class="icon-chevron-right"></i></a>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-lg-12">
                    <div class="popular-category-slider owl-carousel">
                        <?php $__currentLoopData = $categories2->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item">
                                <div class="product-card">
                                    <div class="product-thumb">
                                        <img class="lazy"
                                            data-src="<?php echo e(asset('storage')); ?>/<?php echo e($product->featured_image); ?>"
                                            alt="Product">
                                        <div class="product-button-group">
                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.add_to_wishlist', ['id' => $product->id])); ?>"
                                                    title="Wishlist"><i class="icon-heart"></i></a>
                                            <?php else: ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.register')); ?>" title="Wishlist"><i
                                                        class="icon-heart"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.add_to_compare', ['id' => $product->id])); ?>"
                                                    title="Compare"><i class="icon-repeat"></i></a>
                                            <?php else: ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.register')); ?>" title="Compare"><i
                                                        class="icon-repeat"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.add_to_cart', ['id' => $product->id])); ?>"
                                                    title="To Cart"><i class="icon-shopping-cart"></i>
                                                </a>
                                            <?php else: ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.register')); ?>" title="To Cart"><i
                                                        class="icon-shopping-cart"></i>
                                                </a>
                                            <?php endif; ?>



                                        </div>
                                    </div>
                                    <div class="product-card-body">
                                        <div class="product-category"><a href="/shop/category/<?php echo e($categories2->slug); ?>"><?php echo e($categories2->name); ?></a>
                                        </div>
                                        <h3 class="product-title"><a
                                                href="<?php echo e(route('user.product_details', ['slug' => $product->slug])); ?>">
                                                <?php echo e(\Illuminate\Support\Str::substr($product->name, 0, 50)); ?>

                                            </a></h3>

                                        <h4 class="product-price">
                                            <del>$<?php echo e($product->previous_price); ?></del>

                                            $<?php echo e($product->current_price); ?>

                                        </h4>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bannner-section mt-60">
        <div class="container ">
            <div class="row gx-3">
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($second_three_column_value->image1); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($second_three_column_value->title1); ?></p>
                            <h4><?php echo e($second_three_column_value->sub_title1); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($second_three_column_value->image2); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($second_three_column_value->title2); ?></p>
                            <h4><?php echo e($second_three_column_value->sub_title2); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($second_three_column_value->image3); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($second_three_column_value->title3); ?></p>
                            <h4><?php echo e($second_three_column_value->sub_title3); ?></h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="deal-of-day-section mt-20">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="h3"><?php echo e($categories3->name); ?></h2>
                        <div class="right-area">
                            <a class="right_link" href="">View
                                All <i class="icon-chevron-right"></i></a>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-lg-12">
                    <div class="popular-category-slider owl-carousel">
                        <?php $__currentLoopData = $categories3->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item">
                                <div class="product-card">
                                    <div class="product-thumb">
                                        <img class="lazy"
                                            data-src="<?php echo e(asset('storage')); ?>/<?php echo e($product->featured_image); ?>"
                                            alt="Product">
                                        <div class="product-button-group">
                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.add_to_wishlist', ['id' => $product->id])); ?>"
                                                    title="Wishlist"><i class="icon-heart"></i></a>
                                            <?php else: ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.register')); ?>" title="Wishlist"><i
                                                        class="icon-heart"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.add_to_compare', ['id' => $product->id])); ?>"
                                                    title="Compare"><i class="icon-repeat"></i></a>
                                            <?php else: ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.register')); ?>" title="Compare"><i
                                                        class="icon-repeat"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.add_to_cart', ['id' => $product->id])); ?>"
                                                    title="To Cart"><i class="icon-shopping-cart"></i>
                                                </a>
                                            <?php else: ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.register')); ?>" title="To Cart"><i
                                                        class="icon-shopping-cart"></i>
                                                </a>
                                            <?php endif; ?>



                                        </div>
                                    </div>
                                    <div class="product-card-body">
                                        <div class="product-category"><a href="/shop/category/<?php echo e($categories3->slug); ?>"><?php echo e($categories3->name); ?></a>
                                        </div>
                                        <h3 class="product-title"><a
                                                href="<?php echo e(route('user.product_details', ['slug' => $product->slug])); ?>">
                                                <?php echo e(\Illuminate\Support\Str::substr($product->name, 0, 50)); ?>

                                            </a></h3>

                                        <h4 class="product-price">
                                            <del>$<?php echo e($product->previous_price); ?></del>

                                            $<?php echo e($product->current_price); ?>

                                        </h4>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bannner-section mt-60">
        <div class="container ">
            <div class="row gx-3">
                <div class="col-md-6">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($third_two_column_value->image1); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($third_two_column_value->title1); ?></p>
                            <h4><?php echo e($third_two_column_value->sub_title1); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($third_two_column_value->image2); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($third_two_column_value->title2); ?></p>
                            <h4><?php echo e($third_two_column_value->sub_title2); ?></h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="deal-of-day-section mt-20">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2 class="h3"><?php echo e($categories4->name); ?></h2>
                        <div class="right-area">
                            <a class="right_link" href="">View
                                All <i class="icon-chevron-right"></i></a>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-lg-12">
                    <div class="popular-category-slider owl-carousel">
                        <?php $__currentLoopData = $categories4->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item">
                                <div class="product-card">
                                    <div class="product-thumb">
                                        <img class="lazy"
                                            data-src="<?php echo e(asset('storage')); ?>/<?php echo e($product->featured_image); ?>"
                                            alt="Product">
                                        <div class="product-button-group">
                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.add_to_wishlist', ['id' => $product->id])); ?>"
                                                    title="Wishlist"><i class="icon-heart"></i></a>
                                            <?php else: ?>
                                                <a class="product-button wishlist_store"
                                                    href="<?php echo e(route('user.register')); ?>" title="Wishlist"><i
                                                        class="icon-heart"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.add_to_compare', ['id' => $product->id])); ?>"
                                                    title="Compare"><i class="icon-repeat"></i></a>
                                            <?php else: ?>
                                                <a data-target="" class="product-button product_compare"
                                                    href="<?php echo e(route('user.register')); ?>" title="Compare"><i
                                                        class="icon-repeat"></i></a>
                                            <?php endif; ?>

                                            <?php if(Auth::user() && Auth::user()->id): ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.add_to_cart', ['id' => $product->id])); ?>"
                                                    title="To Cart"><i class="icon-shopping-cart"></i>
                                                </a>
                                            <?php else: ?>
                                                <a class="product-button add_to_single_cart" data-target="563"
                                                    href="<?php echo e(route('user.register')); ?>" title="To Cart"><i
                                                        class="icon-shopping-cart"></i>
                                                </a>
                                            <?php endif; ?>



                                        </div>
                                    </div>
                                    <div class="product-card-body">
                                        <div class="product-category"><a href="/shop/category/<?php echo e($categories4->slug); ?>"><?php echo e($categories4->name); ?></a>
                                        </div>
                                        <h3 class="product-title"><a
                                                href="<?php echo e(route('user.product_details', ['slug' => $product->slug])); ?>">
                                                <?php echo e(\Illuminate\Support\Str::substr($product->name, 0, 50)); ?>

                                            </a></h3>

                                        <h4 class="product-price">
                                            <del>$<?php echo e($product->previous_price); ?></del>

                                            $<?php echo e($product->current_price); ?>

                                        </h4>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bannner-section mt-60">
        <div class="container ">
            <div class="row gx-3">
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($four_three_column_value->image1); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($four_three_column_value->title1); ?></p>
                            <h4><?php echo e($four_three_column_value->sub_title1); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($four_three_column_value->image2); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($four_three_column_value->title2); ?></p>
                            <h4><?php echo e($four_three_column_value->sub_title2); ?></h4>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="#" class="genius-banner">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($four_three_column_value->image3); ?>" alt="">
                        <div class="inner-content">
                            <p><?php echo e($four_three_column_value->title3); ?></p>
                            <h4><?php echo e($four_three_column_value->sub_title3); ?></h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ecomarce-website\resources\views/user/home.blade.php ENDPATH**/ ?>